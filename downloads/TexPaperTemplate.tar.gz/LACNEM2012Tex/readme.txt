# Readme.txt
# 
# @author Damien Simonnet <simonnet@ecole.ensicaen.fr>
#
# @version 1.0 (July 24, 2009)
# @version 1.1 (September 03, 2009)
# add optional command \secondauthoraddr
# @version 1.2 (September 11, 2009)
# @version 1.3 (February 2012, adapted for LACNEM by Sergio Velastin)
# enables to use \\ in the command \@authoraddr
#
# Template latex for LACNEM 2009
#


# 1 - Content

Folder "template":
	lacnem2012.sty: package template
	preamble.tex: latex file that you have to include in the preamble 

Folder "example":
	lacnem2012.bib: list of all references
	example.txt: using sample of this template

# 2 - Compiling
The compiling order is the following: .tex -> .div -> .ps -> .pdf
	 
